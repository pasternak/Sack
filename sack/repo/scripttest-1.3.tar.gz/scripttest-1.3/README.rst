scripttest
==========

.. image:: https://pypip.in/v/ScriptTest/badge.png
        :target: https://pypi.python.org/pypi/scripttest

.. image:: https://secure.travis-ci.org/pypa/scripttest.png
   :target: http://travis-ci.org/pypa/scripttest

scripttest is a library to help you test your interactive command-line
applications.

With it you can easily run the command (in a subprocess) and see the
output (stdout, stderr) and any file modifications.

* The `source repository <https://github.com/pypa/scripttest>`_.
* The `documentation <https://scripttest.readthedocs.org/>`_.
